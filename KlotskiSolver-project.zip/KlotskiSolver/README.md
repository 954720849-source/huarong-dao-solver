# 华容道·解局大师

Android 原生 Java 版，包含：

- 内置 2 个可玩关卡
- 手指拖动棋子
- 自定义 4×5 局面
- 自动检测局面是否合法、是否有解
- 无解时弹窗提示
- 有解时把自定义局面直接转为新的可玩关卡
- BFS 路径求解

## 构建 APK

需要 JDK 17、Android SDK（platforms;android-35、build-tools;35.0.0）以及 Gradle 8.10.2。

本项目附带 GitHub Actions 工作流：`.github/workflows/build.yml`。把项目上传 GitHub 后，在 Actions 中手动运行 `Build APK`，构建产物为 `app-debug.apk`。
