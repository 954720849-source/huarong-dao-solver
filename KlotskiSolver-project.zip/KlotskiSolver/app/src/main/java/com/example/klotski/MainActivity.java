package com.example.klotski;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
    BoardView board; TextView status; int[] levelX,levelY; boolean editor=false; int tool=-1;
    final int[][] LEVELS={
      // Cao, V1,V2,V3,V4, HOR, P1,P2,P3,P4 (x,y pairs)
      {0,3, 1,0, 3,3, 0,1, 2,3, 2,2, 2,1, 0,0, 3,0, 2,0},
      {0,3, 1,0, 3,3, 0,1, 2,3, 1,2, 2,1, 0,0, 3,0, 2,0}
    };
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(245,241,232));getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); build(); loadClassic(0);}
    void build(){
      LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(10),dp(14),dp(8));root.setBackgroundColor(Color.rgb(245,241,232));
      TextView title=new TextView(this);title.setText("华容道 · 解局大师");title.setTextSize(24);title.setTextColor(Color.rgb(43,41,38));title.setTypeface(null,1);root.addView(title,new LinearLayout.LayoutParams(-1,dp(44)));
      status=new TextView(this);status.setText("选择关卡开始");status.setTextSize(15);status.setTextColor(Color.DKGRAY);root.addView(status,new LinearLayout.LayoutParams(-1,dp(34)));
      board=new BoardView(this);root.addView(board,new LinearLayout.LayoutParams(-1,0,1));
      LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);root.addView(bar,new LinearLayout.LayoutParams(-1,dp(52)));
      Button prev=btn("上一关"), next=btn("下一关"), edit=btn("自定义");bar.addView(prev,eq());bar.addView(next,eq());bar.addView(edit,eq());
      prev.setOnClickListener(v->{loadClassic(0);});next.setOnClickListener(v->{loadClassic(1);});edit.setOnClickListener(v->{enterEditor();});
      setContentView(root);
    }
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;} LinearLayout.LayoutParams eq(){return new LinearLayout.LayoutParams(0,dp(48),1);}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    void loadClassic(int i){editor=false;tool=-1; int[] a=LEVELS[i];levelX=new int[KlotskiSolver.N];levelY=new int[KlotskiSolver.N];for(int p=0;p<10;p++){levelX[p]=a[p*2];levelY[p]=a[p*2+1];} board.setState(levelX,levelY,false); status.setText("关卡 "+(i+1)+" · 步数 0");}
    void enterEditor(){editor=true;tool=0;levelX=new int[10];levelY=new int[10];Arrays.fill(levelX,-1);Arrays.fill(levelY,-1);board.setState(levelX,levelY,true);status.setText("自定义：先选棋子，再点棋盘放置"); new AlertDialog.Builder(this).setTitle("自定义局面").setMessage("棋盘为4×5。按下棋子类型后点棋盘放置：曹操、竖将×4、横将×1、兵×4。完成后点“检查解”。").setPositiveButton("知道了",null).show();}
    void checkCustom(){
      if(!editor)return; int[] x=board.x.clone(),y=board.y.clone(); for(int p=0;p<10;p++)if(x[p]<0||y[p]<0){new AlertDialog.Builder(this).setTitle("局面不完整").setMessage("请放置全部棋子后再检查。").setPositiveButton("好",null).show();return;}
      List<KlotskiSolver.State> path=KlotskiSolver.solve(x,y,true); if(path==null){new AlertDialog.Builder(this).setTitle("无解").setMessage("这个局面无法把曹操移到出口，请调整摆放位置后再试。").setPositiveButton("好",null).show();}
      else {board.setState(x,y,false);editor=false;status.setText("检测成功 · 解法约 "+(path.size()-1)+" 步，开始挑战");new AlertDialog.Builder(this).setTitle("有解！").setMessage("已找到通路，共 "+(path.size()-1)+" 步。现在把它当作新关卡来玩吧。").setPositiveButton("开始",null).show();}
    }
    void selectTool(){ final String[] names={"曹操（2×2）","竖将1（1×2）","竖将2（1×2）","竖将3（1×2）","竖将4（1×2）","横将（2×1）","兵1","兵2","兵3","兵4","擦除","检查解"}; new AlertDialog.Builder(this).setTitle("选择编辑工具").setItems(names,(d,w)->{if(w==11){checkCustom();return;}tool=w;status.setText(names[w]+"：点击棋盘放置或擦除");}).show(); }
    class BoardView extends View{
      Paint p=new Paint(1); int[] x=new int[10],y=new int[10]; boolean editMode=false; float cw,ch; int downPiece=-1; float sx,sy;
      BoardView(Context c){super(c);setBackgroundColor(Color.TRANSPARENT);}
      void setState(int[] xx,int[] yy,boolean e){x=xx.clone();y=yy.clone();editMode=e;invalidate();}
      protected void onDraw(Canvas c){super.onDraw(c);cw=getWidth()/4f;ch=Math.min(getHeight()/5f,cw);float ox=(getWidth()-cw*4)/2,oy=8;
        p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(55,48,42));c.drawRoundRect(ox-5,oy-5,ox+cw*4+5,oy+ch*5+5,18,18,p);
        for(int r=0;r<5;r++)for(int col=0;col<4;col++){p.setColor(Color.rgb(224,215,198));c.drawRect(ox+col*cw+2,oy+r*ch+2,ox+(col+1)*cw-2,oy+(r+1)*ch-2,p);}
        String[] labels={"曹操","将1","将2","将3","将4","横将","兵","兵","兵","兵"}; int[] colors={0xffb23a3a,0xff356f9b,0xff356f9b,0xff356f9b,0xff356f9b,0xff9b6a2f,0xff657a3f,0xff657a3f,0xff657a3f,0xff657a3f};
        for(int i=0;i<10;i++) if(x[i]>=0&&y[i]>=0){float l=ox+x[i]*cw+4,t=oy+y[i]*ch+4,r=ox+(x[i]+KlotskiSolver.widths()[i])*cw-4,b=oy+(y[i]+KlotskiSolver.heights()[i])*ch-4;p.setColor(colors[i]);c.drawRoundRect(l,t,r,b,14,14,p);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(Math.min(cw*.26f,ch*.22f));c.drawText(labels[i],(l+r)/2,(t+b)/2-p.ascent()/2,p);}
        p.setColor(Color.WHITE);p.setTextSize(12);p.setTextAlign(Paint.Align.CENTER);c.drawText("出口",ox+cw*2,oy+ch*5+20,p);
      }
      int cellX(float fx){return (int)((fx-(getWidth()-cw*4)/2)/cw);} int cellY(float fy){return (int)((fy-8)/ch);}
      public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getX();sy=e.getY();return true;}if(e.getAction()==MotionEvent.ACTION_UP){float ex=e.getX(),ey=e.getY();int c=cellX(ex),r=cellY(ey);if(c<0||c>=4||r<0||r>=5)return true;
          if(editMode){if(tool<0||tool==11){selectTool();return true;}if(tool==10){for(int i=0;i<10;i++)if(contains(i,c,r)){x[i]=-1;y[i]=-1;invalidate();return true;}return true;} int i=tool; if(i>=0&&i<10){if(x[i]>=0){new AlertDialog.Builder(MainActivity.this).setMessage("这个棋子已经放置。可用“擦除”删除后重新放置。").setPositiveButton("好",null).show();} else {int w=KlotskiSolver.widths()[i],h=KlotskiSolver.heights()[i]; if(c+w<=4&&r+h<=5){for(int q=0;q<10;q++)if(x[q]>=0&&rectOverlap(c,r,w,h,x[q],y[q],KlotskiSolver.widths()[q],KlotskiSolver.heights()[q])){new AlertDialog.Builder(MainActivity.this).setMessage("位置与其他棋子重叠。").setPositiveButton("好",null).show();return true;}x[i]=c;y[i]=r;invalidate();}} return true;}
          // play: find piece at touched cell and slide it in drag direction or tap cycles to legal move.
          int i=-1;for(int q=0;q<10;q++)if(contains(q,c,r)){i=q;break;} if(i<0)return true; int dc=(int)Math.signum(ex-sx),dr=(int)Math.signum(ey-sy); if(Math.abs(ex-sx)<10&&Math.abs(ey-sy)<10)return true; movePiece(i,dc,dr);return true;
      }return true;}
      boolean contains(int i,int c,int r){return x[i]>=0&&c>=x[i]&&c<x[i]+KlotskiSolver.widths()[i]&&r>=y[i]&&r<y[i]+KlotskiSolver.heights()[i];}
      boolean rectOverlap(int ax,int ay,int aw,int ah,int bx,int by,int bw,int bh){return ax<bx+bw&&ax+aw>bx&&ay<by+bh&&ay+ah>by;}
      void movePiece(int i,int dc,int dr){if(dc==0&&dr==0)return;int nx=x[i]+dc,ny=y[i]+dr,w=KlotskiSolver.widths()[i],h=KlotskiSolver.heights()[i];if(nx<0||ny<0||nx+w>4||ny+h>5)return;for(int q=0;q<10;q++)if(q!=i&&x[q]>=0&&rectOverlap(nx,ny,w,h,x[q],y[q],KlotskiSolver.widths()[q],KlotskiSolver.heights()[q]))return;x[i]=nx;y[i]=ny;invalidate();int moves=0; // rough move counter shown from actual state hash omitted
        if(i==KlotskiSolver.CAO&&x[i]==1&&y[i]==3){new AlertDialog.Builder(MainActivity.this).setTitle("恭喜通关").setMessage("曹操已到达出口！").setPositiveButton("下一关",(d,wv)->loadClassic(1)).show();}
      }
    }
}
