package com.example.klotski;

import java.util.*;

/** Exact BFS solver for the standard 4x5 Klotski layout. */
public final class KlotskiSolver {
    public static final int W=4,H=5,N=10;
    public static final int CAO=0, V1=1,V2=2, HOR=3, P1=4,P2=5,P3=6,P4=7,P5=8,P6=9;
    // width,height for the 10 pieces; 10th is unused in standard 9-piece classic layout but kept flexible for editor compatibility.
    private static final int[] PW={2,1,1,1,1,2,1,1,1,1};
    private static final int[] PH={2,2,2,2,2,1,1,1,1,1};

    public static final class Piece { public int x,y; public Piece(int x,int y){this.x=x;this.y=y;} }
    public static final class State {
        public final int[] x,y;
        public State(int[] x,int[] y){this.x=x.clone();this.y=y.clone();}
        public String key(){StringBuilder s=new StringBuilder();for(int i=0;i<x.length;i++)s.append((char)('A'+x[i])).append((char)('A'+y[i]));return s.toString();}
    }
    public static int[] widths(){return PW.clone();}
    public static int[] heights(){return PH.clone();}

    public static boolean valid(int[] x,int[] y){
        if(x.length!=N||y.length!=N)return false;
        boolean[][] g=new boolean[H][W];
        for(int p=0;p<N;p++){
            if(x[p]<0||y[p]<0||x[p]+PW[p]>W||y[p]+PH[p]>H)return false;
            for(int r=y[p];r<y[p]+PH[p];r++)for(int c=x[p];c<x[p]+PW[p];c++){
                if(g[r][c])return false; g[r][c]=true;
            }
        }
        return true;
    }
    private static int emptyCount(int[] x,int[] y){boolean[][] g=new boolean[H][W];for(int p=0;p<N;p++)for(int r=y[p];r<y[p]+PH[p];r++)for(int c=x[p];c<x[p]+PW[p];c++)g[r][c]=true;int z=0;for(int r=0;r<H;r++)for(int c=0;c<W;c++)if(!g[r][c])z++;return z;}
    public static int solveDistance(int[] x,int[] y){List<State> p=solve(x,y,true);return p==null?-1:p.size()-1;}
    public static List<State> solve(int[] x,int[] y,boolean wantPath){
        if(!valid(x,y)||emptyCount(x,y)!=2)return null;
        State start=new State(x,y); String sk=start.key();
        ArrayDeque<State> q=new ArrayDeque<>(); q.add(start);
        Map<String,String> parent=new HashMap<>(); Map<String,State> states=new HashMap<>(); parent.put(sk,null); states.put(sk,start);
        while(!q.isEmpty()){
            State s=q.remove();
            if(s.x[CAO]==1 && s.y[CAO]==3){
                if(!wantPath)return Collections.singletonList(s);
                ArrayList<State> rev=new ArrayList<>(); String k=s.key(); while(k!=null){State z=states.get(k);rev.add(z);k=parent.get(k);} Collections.reverse(rev); return rev;
            }
            boolean[][] occ=new boolean[H][W]; int[][] who=new int[H][W]; for(int r=0;r<H;r++)Arrays.fill(who[r],-1);
            for(int p=0;p<N;p++)for(int r=s.y[p];r<s.y[p]+PH[p];r++)for(int c=s.x[p];c<s.x[p]+PW[p];c++){occ[r][c]=true;who[r][c]=p;}
            int[][] dirs={{1,0},{-1,0},{0,1},{0,-1}};
            for(int p=0;p<N;p++)for(int[] d:dirs){int nx=s.x[p]+d[0],ny=s.y[p]+d[1];if(nx<0||ny<0||nx+PW[p]>W||ny+PH[p]>H)continue;boolean ok=true;
                for(int r=ny;r<ny+PH[p]&&ok;r++)for(int c=nx;c<nx+PW[p];c++){int w=who[r][c];if(w!=-1&&w!=p){ok=false;break;}}
                if(!ok)continue; int[] xx=s.x.clone(),yy=s.y.clone();xx[p]=nx;yy[p]=ny;State ns=new State(xx,yy);String nk=ns.key();if(!parent.containsKey(nk)){parent.put(nk,s.key());states.put(nk,ns);q.add(ns);}
            }
        }
        return null;
    }
}
